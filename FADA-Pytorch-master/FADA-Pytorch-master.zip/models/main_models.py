import torch
import torch.nn as nn
import torch.nn.functional as F
from models.BasicModule import BasicModule
import numpy as np
class DCD(BasicModule):
    def __init__(self,h_features=64,input_features=128):
        super(DCD,self).__init__()

        self.fc1=nn.Linear(input_features,h_features)
        self.fc2=nn.Linear(h_features,h_features)
        self.fc3=nn.Linear(h_features,4)

    def forward(self,inputs):
        out=F.relu(self.fc1(inputs))
        out=self.fc2(out)
        return F.softmax(self.fc3(out),dim=1)

class Classifier(BasicModule):
    def __init__(self,input_features=64):
        super(Classifier,self).__init__()
        self.fc=nn.Linear(input_features,10)

    def forward(self,input):
        return F.softmax(self.fc(input),dim=1)

class Encoder(BasicModule):
    def __init__(self):
        super(Encoder,self).__init__()

        self.conv1=nn.Conv2d(1,6,5)
        self.conv2=nn.Conv2d(6,16,5)
        self.fc1=nn.Linear(256,120)
        self.fc2=nn.Linear(120,84)
        self.fc3=nn.Linear(84,64)

    def forward(self,input):
        out=F.relu(self.conv1(input))
        out=F.max_pool2d(out,2)
        out=F.relu(self.conv2(out))
        out=F.max_pool2d(out,2)
        out=out.view(out.size(0),-1)

        out=F.relu(self.fc1(out))
        out=F.relu(self.fc2(out))
        out=self.fc3(out)

        return out

class Transformer(BasicModule):
    def __init__(self):
        super(Transformer, self).__init__()
        self.fc1=nn.Linear(64,100)
        self.fc2=nn.Linear(100,64)
    def forward(self, input):
        out=F.relu(self.fc1(input))
        out=self.fc2(out)
        return out

def CORAL(X_s,X_t,device):
    dim=X_s.shape[1]
    n_s=X_s.shape[0]
    ones=torch.ones([1,n_s]).to(device)
    ones=ones.mm(X_s)

    Cs=(X_s.transpose(0,1).mm(X_s)-ones.transpose(0,1).mm(ones)/n_s)/(n_s-1)

    n_t=X_t.shape[0]
    ones = torch.ones([1, n_t]).to(device)
    ones=ones.mm(X_t)

    Ct=(X_t.transpose(0,1).mm(X_t)-ones.transpose(0,1).mm(ones)/n_t)/(n_t-1)

    loss=torch.norm(Cs-Ct)/4/dim/dim
    return loss

